﻿global using VOD.Application.Common;
global using Blazored.LocalStorage;
global using VOD.Application.Common.DTOs;
global using VOD.Application.Common.Extensions;